<?php

namespace App\Http\Controllers;

use App\Models\Administrador;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class AdministradorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $datos['administradores'] = Administrador::paginate(5);
        return view('administrador.index', $datos);
    }

    public function index2(Request $request)
    {
        $Titulo = $request->get('buscar');

        $datos['administradores'] = Administrador::where('titulo','like',"%$Titulo%")->paginate(8);
        
        return view('administrador.index2', $datos);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('administrador.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $campos=[

            'Titulo'=>'required|string|max:100',
            'Isbn'=>'required|integer|max:9999999999999',
            'Autor'=>'required|string|max:100',
            'Editorial'=>'required|string|max:100',
            'Año'=>'required|integer|max:10000',
            'Ejemplares'=>'required|integer|max:10000',
            'Precio'=>'required|integer|max:10000',
            'Imagen'=>'required|max:10000|mimes:jpeg,png,jpg,gif',
            'Descripcion'=>'required|string|max:10000',

        ];

        $mensaje=[

            'required'=>'Se requiere del :attribute',
            'Editorial.required'=>'Se requiere la editorial',
            'Imagen.required'=>'Se requiere una imagen',
            'Ejemplares.required'=>'Se requiere de la cantidad de ejemplares',
            'Descripcion.required'=>'Se requiere de una descripcion',

        ];

        $this->validate($request, $campos, $mensaje);

        $datosAdministrador = request()->except('_token');

        if($request->hasFile('Imagen')){
            $datosAdministrador['Imagen']=$request->file('Imagen')->store('uploads','public');
        }

        Administrador::insert($datosAdministrador);
       // return response()->json($datosAdministrador);
       return redirect('administrador')->with('mensaje','Libro registrado exitosamente');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Administrador  $administrador
     * @return \Illuminate\Http\Response
     */
    public function show(Administrador $administrador)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Administrador  $administrador
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $administrador=Administrador::findOrFail($id);
        return view('administrador.edit', compact('administrador'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Administrador  $administrador
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $campos=[

            'Titulo'=>'required|string|max:100',
            'Isbn'=>'required|integer|max:9999999999999',
            'Autor'=>'required|string|max:100',
            'Editorial'=>'required|string|max:100',
            'Año'=>'required|integer|max:10000',
            'Ejemplares'=>'required|integer|max:10000',
            'Precio'=>'required|integer|max:10000',
            'Descripcion'=>'required|string|max:10000',

        ];

        $mensaje=[

            'required'=>'Se requiere del :attribute',
            'Editorial.required'=>'Se requiere la editorial',
            'Ejemplares.required'=>'Se requiere de la cantidad de ejemplares',
            'Descripcion.required'=>'Se requiere de una descripcion',

        ];
        if($request->hasFile('Imagen')){

            $campos=['Imagen'=>'required|max:10000|mimes:jpeg,png,jpg,gif',];
            $mensaje=['Imagen.required'=>'Se requiere una imagen',];
        }
        $this->validate($request, $campos, $mensaje);


        $datosAdministrador = request()->except(['_token','_method']);

        if($request->hasFile('Imagen')){
            $administrador=Administrador::findOrFail($id);
            Storage::delete('public/'.$administrador->Imagen);
            $datosAdministrador['Imagen']=$request->file('Imagen')->store('uploads','public');
        }

        Administrador::where('id','=',$id)->update($datosAdministrador);
        $administrador=Administrador::findOrFail($id);
        //return view('administrador.edit', compact('administrador'));
        return redirect('administrador')->with('mensaje','Libro editado exitosamente');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Administrador  $administrador
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $administrador=Administrador::findOrFail($id);

        if(Storage::delete('public/'.$administrador->Imagen)){

            Administrador::destroy($id);

        }

        
        return redirect('administrador')->with('mensaje','Libro borrado exitosamente');
    }
}
