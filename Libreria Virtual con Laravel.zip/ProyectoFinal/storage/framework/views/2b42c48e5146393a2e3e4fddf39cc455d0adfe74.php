
<?php $__env->startSection('content'); ?>
<div class="container">



<table class="table table-dark table-striped" style="text-align:center;vertical-align:middle;border-color:white; border:2px">

    <thead class="thead-dark" style="text-align:center;vertical-align:middle;border-collapse:collapse">
        <tr>

            
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Correo</th>
            <th>Acciones</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
        <tr>
            <td><?php echo e($cliente->Nombre); ?></td>
            <td><?php echo e($cliente->Apellido); ?></td>
            <td><?php echo e($cliente->Correo); ?></td>

            <td>
                
                <a class="btn btn-success">
                    Enviar correo
                </a>

                
                
        </tr>
        
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>
<div class="row">
    <div class="col-12 d-flex pt-5 justify-content-center">
<?php echo $clientes->links(); ?>

    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProyectoFinal\resources\views/cliente/index.blade.php ENDPATH**/ ?>