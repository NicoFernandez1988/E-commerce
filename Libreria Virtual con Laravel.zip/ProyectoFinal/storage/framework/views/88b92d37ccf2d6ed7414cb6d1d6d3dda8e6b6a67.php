

<?php $__env->startSection('content'); ?>
<div class="container">


<?php if(Session::has('mensaje')): ?>
    <div style="text-align: center" class="alert alert-success" role="alert">

    <?php echo e(Session::get('mensaje')); ?>

    

    </div>

<?php endif; ?>



<a href="<?php echo e(url('administrador/create')); ?>" class="btn btn-success"> Registrar nuevo libro </a>
<br>
<br>
<table class="table table-dark table-striped" style="text-align:center;vertical-align:middle;border-color:white; border:2px">

    <thead class="thead-dark" style="text-align:center;vertical-align:middle;border-collapse:collapse">
        <tr>

            
            <th>Titulo</th>
            <th>Isbn</th>
            <th>Autor</th>
            <th>Editorial</th>
            <th>Año de publicacion</th>
            <th>Cantidad de ejemplares</th>
            <th>Precio</th>
            <th>Imagen</th>
            <th>Descripcion</th>
            <th>Acciones</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $administradores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $administrador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
        <tr>
            <td><?php echo e($administrador->Titulo); ?></td>
            <td><?php echo e($administrador->Isbn); ?></td>
            <td><?php echo e($administrador->Autor); ?></td>
            <td><?php echo e($administrador->Editorial); ?></td>
            <td><?php echo e($administrador->Año); ?></td>
            <td><?php echo e($administrador->Ejemplares); ?></td>
            <td><?php echo e($administrador->Precio); ?></td>

            <td>
                <img class="img-thumbnail img-fluid" src="<?php echo e(asset('storage').'/'.$administrador->Imagen); ?>" width="150" alt="">
                
            
            </td>

            <td><?php echo e($administrador->Descripcion); ?></td>
            <td>
                
                <a href="<?php echo e(url('/administrador/'.$administrador->id.'/edit')); ?>" class="btn btn-warning" style="margin-bottom: 15px">
                    Editar
                </a>
                
                <form action="<?php echo e(url('/administrador/'.$administrador->id)); ?>" class="d-inline" class="btn btn-danger" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('DELETE')); ?>

                <input type="submit" class="btn btn-danger d-inline"  onclick="return confirm('¿Esta seguro que desea borrar el libro?')"
                value="Borrar" >
                </form>
                </td>

                
        </tr>
        
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>
<div class="row">
    <div class="col-12 d-flex pt-5 justify-content-center">
<?php echo $administradores->links(); ?>

    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProyectoFinal\resources\views/administrador/index.blade.php ENDPATH**/ ?>